<!DOCTYPE html>
<html>
<head>
<title></title>
</head>

<body>
<?php
echo 'hello world'
// Validation file used for the unlockscreen plugin type 'form'. Notice the this file only checks if there is data present
?>
</body>
</html>
