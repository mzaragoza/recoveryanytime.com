<div class="inner-padding">
<p>I am loaded with AJAX...</p>
</div>
